Summernote Plugins
=============

Some plugins for the [Summernote WYSIWYG](https://github.com/summernote/summernote/)

Nugget
-------------

Allow users to insert custom "nuggets" into the WYSIWYG.

