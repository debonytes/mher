magic-wand-js
=============

Magic wand tool (fuzzy selection) by color for Javascript

Live example: http://jsfiddle.net/Tamersoul/dr7Dw/

Magic Wand Control for Openlayers 2.13 (use only for "google" and "grid" layers with CORS support)

Live Openlayers example: http://jsfiddle.net/Tamersoul/uBL5C/

Enjoy.
